#include <SFML/Graphics.hpp>
#include <iostream>

#include "menu.h"

using namespace std;

int main()
{

    menu* menuUkami = menu::getInstance();

    return EXIT_SUCCESS;
}
