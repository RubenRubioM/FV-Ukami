#include "Ninja.h"

Ninja::Ninja()
{

}

Ninja::~Ninja()
{
    //dtor
}
